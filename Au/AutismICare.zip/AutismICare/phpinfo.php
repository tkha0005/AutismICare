<?php
 echo "Hello, world!";
?>